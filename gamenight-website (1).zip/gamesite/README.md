# 🎮 GameNight — Free Multiplayer Game Platform

A complete multiplayer game website you can host **100% free** on GitHub Pages + Firebase.

## 🚀 Quick Setup (15 minutes)

### Step 1 — Download & Upload to GitHub

1. Go to [github.com](https://github.com) and sign in (or create a free account)
2. Click the **+** button → **New repository**
3. Name it: `gamenight` (or anything you like)
4. Click **Create repository**
5. Upload ALL these files by dragging them into GitHub

Your file structure should look like:
```
gamenight/
├── index.html          ← Main page
├── README.md           ← This file
└── games/
    ├── tictactoe.html  ← Tic-Tac-Toe game
    └── chess.html      ← Chess game (coming soon)
```

### Step 2 — Enable GitHub Pages (free hosting)

1. In your GitHub repo, click **Settings** (top menu)
2. Click **Pages** (left sidebar)
3. Under "Source", select **main** branch
4. Click **Save**
5. Wait 1-2 minutes, then visit: `https://YOUR-USERNAME.github.io/gamenight`

✅ Your website is now live for free!

---

## 🔥 Step 3 — Add Firebase (for real multiplayer)

Right now the games work in "demo mode" on one screen. To play with real friends across the internet, you need Firebase (free).

### Create your Firebase project:

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → name it "gamenight" → click through the setup
3. In your new project, click **Realtime Database** (left sidebar)
4. Click **Create Database** → choose any location → start in **test mode**
5. Click **Project Settings** (gear icon) → scroll to **Your apps**
6. Click **</>** (web app) → register app → copy the config

### Paste your config:

Open `games/tictactoe.html` and find this section:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",          // ← Replace these
  authDomain: "YOUR_PROJECT...",
  databaseURL: "https://YOUR...",
  ...
};
```

Replace it with YOUR config from Firebase (looks like):
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyAbc123...",
  authDomain: "my-gamenight.firebaseapp.com",
  databaseURL: "https://my-gamenight-default-rtdb.firebaseio.com",
  projectId: "my-gamenight",
  storageBucket: "my-gamenight.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

Save the file and push to GitHub. Done! 🎉

---

## 🎮 How players use it

1. **Host** goes to your website, clicks **Create a Room**, picks a game
2. Host gets a **6-letter code** (like `ABC123`)
3. Host shares that code with friends via text, Discord, etc.
4. **Friends** go to the same website, click **Enter Room Code**, type the code
5. Everyone's in! Host clicks **Start Game**

---

## 🛠 Adding More Games

To add a new game, create `games/mygame.html` and add it to the grid in `index.html`:

```html
<a class="game-card" href="games/mygame.html">
  <span class="game-icon">🎯</span>
  <div class="game-title">My Game</div>
  <div class="game-desc">Description here.</div>
  <div class="game-meta">
    <span class="badge badge-green">Live Now</span>
    <span class="players-tag">2 players</span>
  </div>
</a>
```

---

## 💰 Costs

| Service | Cost |
|---|---|
| GitHub Pages | **FREE** forever |
| Firebase Realtime DB | **FREE** up to 1GB + 10GB/month |
| Domain name | Optional (~$12/year if you want mysite.com) |

**Total: $0/month** for hundreds of players.

---

## 🔒 Firebase Security Rules

When you're ready to go public, update your Firebase rules to protect your data.
In Firebase Console → Realtime Database → Rules, paste:

```json
{
  "rules": {
    "rooms": {
      "$roomId": {
        ".read": true,
        ".write": true,
        "game": { ".write": true },
        "chat": {
          "$msgId": { ".write": "!data.exists()" }
        }
      }
    }
  }
}
```

---

## 🙋 Help

- Firebase docs: [firebase.google.com/docs](https://firebase.google.com/docs)
- GitHub Pages docs: [docs.github.com/pages](https://docs.github.com/pages)
- Questions? Open an issue in your repo!
